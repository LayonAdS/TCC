/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import factory.ConnectionFactory;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import modelo.HistoricoCli;


/**
 *
 * @author senai
 */
public class HistoricoCliDAO {
    String codigo_cli; 
    String cod_produto;
    String nome_pro;
    Double preco;
    String tipo;
    String categoria;
    int quantidade;
    
    private final Connection connection;
    
     public HistoricoCliDAO() {
        this.connection = new ConnectionFactory().getConnection();
    }
      public void salvar(HistoricoCli objEm) {
          ResultSet rs = null; 
          
        try {
            String sql;
            String cod = "SELECT * FROM historico WHERE codigo_cli = ? and cod_produto = ?";
            PreparedStatement stmt1 = connection.prepareStatement(cod);
            stmt1.setString(1, objEm.getCodigo_cli());
            stmt1.setString(2, objEm.getCod_produto());
            rs = stmt1.executeQuery();
             
            
            if (rs.next()) {
                sql = "UPDATE historico SET quantidade = ? + quantidade WHERE codigo_cli = ? and cod_produto = ?";
                PreparedStatement stmt = connection.prepareStatement(sql);
                
                stmt.setString(2, objEm.getCodigo_cli());
                stmt.setString(3, objEm.getCod_produto());
                stmt.setInt(1, objEm.getQuantidade());
                stmt.execute();
                stmt.close();

            } else {
                sql = "INSERT INTO historico (codigo_cli,cod_produto, nome_pro,preco,tipo,categoria,quantidade) VALUES(?,?,?,?,?,?,?)";
                PreparedStatement stmt = connection.prepareStatement(sql);

                stmt.setString(1, objEm.getCodigo_cli()); 
                stmt.setString(2, objEm.getCod_produto());
                stmt.setString(3, objEm.getNome_pro());
                stmt.setDouble(4, objEm.getPreco());
                stmt.setString(5, objEm.getTipo());
                stmt.setString(6,objEm.getCategoria());
                stmt.setInt(7, objEm.getQuantidade());
                stmt.execute();
                stmt.close();

            }
        } catch (SQLException u) {
            throw new RuntimeException(u);
        }
    }
    public void modificar(HistoricoCli objEm){
        String sql;
        try{
         sql = "UPDATE historico SET quantidade = ? WHERE codigo_cli = ? and cod_produto = ?";
                PreparedStatement stmt = connection.prepareStatement(sql);
                
                stmt.setString(2, objEm.getCodigo_cli());
                stmt.setString(3, objEm.getCod_produto());
                stmt.setInt(1, objEm.getQuantidade());
                stmt.execute();
                stmt.close();
                
                
    }  catch (SQLException u){
       JOptionPane.showMessageDialog(null, "nao foi o modificar"); 
    }
    }
    public double total(HistoricoCli objEm) {
        try{
            String sql = "";
            sql = "select SUM(preco * quantidade) as \"soma\" from historico where codigo_cli = ?;";
            PreparedStatement stmt = connection.prepareStatement(sql);
            stmt.setString(1, objEm.getCodigo_cli());
            stmt.execute();

            ResultSet resultados = stmt.getResultSet();
            resultados.next();
            
            double soma = resultados.getDouble("soma");
            
            stmt.close();
            
            return soma;
        } catch (SQLException ex) {
            Logger.getLogger(HistoricoCliDAO.class.getName()).log(Level.SEVERE, null, ex);
            JOptionPane.showMessageDialog(null, "nao foi");
        }
       
       
      return 0;
    }  

    public ArrayList buscar(HistoricoCli objEm) {
        try {
            String sql = "";
            
                sql = "SELECT cod_produto, nome_pro, tipo, categoria, quantidade FROM historico WHERE codigo_cli = " + objEm.getCodigo_cli() + "";
            
            ArrayList dado = new ArrayList();

            PreparedStatement ps = connection.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {

                dado.add(new Object[]{
                    rs.getInt("cod_produto"),
                    rs.getString("nome_pro"),
                    rs.getDouble("Preco"),
                    rs.getString("Tipo"),
                    rs.getString("Categoria"),
                    rs.getInt("Quantidade"),
                
                });

            }
            ps.close();
            rs.close();

            return dado;
        } catch (SQLException e) {
            e.getMessage();
            JOptionPane.showMessageDialog(null, "Erro preencher a o ArrayList");
            return null;
        }

    }

    public void deletar(HistoricoCli objEm) {
        try {
            String sql;
            if (String.valueOf(objEm.getCodigo_cli()) != null) {
                sql = "DELETE FROM historico WHERE codigo_cli = ? and cod_produto = ?";
                PreparedStatement stmt = connection.prepareStatement(sql);
                stmt.setString(1, objEm.getCodigo_cli());
                stmt.setString(2, objEm.getCod_produto());
                stmt.execute();
                stmt.close();

            }
        } catch (SQLException u) {
            throw new RuntimeException(u);
        }
    }

    public ArrayList listarTodos(HistoricoCli objEm) {
        ResultSet rs = null;
      
        try {

            ArrayList dado = new ArrayList();
            
               String cod = "select * from historico where codigo_cli = ?";
               PreparedStatement stmt1 = connection.prepareStatement(cod);
               stmt1.setString(1, objEm.getCodigo_cli());
              
                rs = stmt1.executeQuery();
          
           
            
             
              
             while(rs.next()){
                dado.add(new Object[]{
                    
                    rs.getString("cod_produto"),
                    rs.getString("nome_pro"),         
                    rs.getString("Tipo"),
                    rs.getString("Categoria"),
                    rs.getDouble("Preco"),
                    rs.getInt("Quantidade"),
                });
             }
            
            stmt1.execute();
            stmt1.close();
            
            return dado;
           
        } catch (SQLException e) {
            e.getMessage();
            JOptionPane.showMessageDialog(null, "Erro preencher o ArrayList");
            return null;
        }
    }
    public static void testarConexao() throws SQLException {
        try (Connection objConnection = new ConnectionFactory().getConnection()) {
            JOptionPane.showMessageDialog(null, "Conexão realizada com sucesso! ");
        }
    }
    
}
