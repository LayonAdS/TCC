/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import factory.ConnectionFactory;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import javax.swing.JOptionPane;
import modelo.CadastroPro;

/**
 *
 * @author senai
 */
public class CadastroProDAO {
    private final Connection connection;
    String cod_produto;
    String nome_pro;
    String marca;
    Double preco;
    String tipo;
    String categoria;
    int quantidade;
    
    
     public CadastroProDAO() {
        this.connection = new ConnectionFactory().getConnection();
    }
      public void salvar(CadastroPro objEm) {
        try {
            String sql;
            if (String.valueOf(objEm.getCod_produto()).isEmpty()) {
                sql = "INSERT INTO produto (nome_pro,marca,preco,tipo,categoria,quantidade) VALUES(?,?,?,?,?,?)";
                PreparedStatement stmt = connection.prepareStatement(sql);

                stmt.setString(1, objEm.getNome_pro());
                stmt.setString(2, objEm.getMarca());
                stmt.setDouble(3, objEm.getPreco());
                stmt.setString(4, objEm.getTipo());
                stmt.setString(5,objEm.getCategoria());
                stmt.setInt(6, objEm.getQuantidade());
                stmt.execute();
                stmt.close();

            } else {
                sql = "UPDATE produto SET nome_pro = ?,  marca = ?, preco = ?, tipo = ?, categoria = ?, quantidade = ?  WHERE cod_produto = ?";

                PreparedStatement stmt = connection.prepareStatement(sql);

                stmt.setString(7, objEm.getCod_produto());
                stmt.setString(1, objEm.getNome_pro());
                stmt.setString(2, objEm.getMarca());
                stmt.setDouble(3, objEm.getPreco());
                stmt.setString(4, objEm.getTipo());
                stmt.setString(5, objEm.getCategoria());
                stmt.setInt(6, objEm.getQuantidade());
                stmt.execute();
                stmt.close();

            }
        } catch (SQLException u) {
            throw new RuntimeException(u);
        }
    }

    public ArrayList buscar(CadastroPro objEm) {
        try {
            String sql = "";
            if (!objEm.getNome_pro().isEmpty()) {
                sql = "SELECT * FROM produto WHERE nome_pro LIKE '%" + objEm.getNome_pro() + "%' ";
            } 
            ArrayList dado = new ArrayList();

            PreparedStatement ps = connection.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {

                dado.add(new Object[]{
                    rs.getInt("cod_produto"),
                    rs.getString("nome_pro"),
                    rs.getString("Marca"),
                    rs.getDouble("Preco"),
                    rs.getString("Tipo"),
                    rs.getString("Categoria"),
                    rs.getInt("Quantidade"),
                
                });

            }
            ps.close();
            rs.close();
            connection.close();

            return dado;
        } catch (SQLException e) {
            e.getMessage();
            JOptionPane.showMessageDialog(null, "Erro preencher o ArrayList");
            return null;
        }

    }

    public void deletar(CadastroPro objEm) {
        try {
            String sql;
            if (!String.valueOf(objEm.getCod_produto()).isEmpty()) {
                sql = "DELETE FROM produto WHERE cod_produto = ?";
                PreparedStatement stmt = connection.prepareStatement(sql);

                stmt.setString(1, objEm.getCod_produto());
                stmt.execute();
                stmt.close();

            }
        } catch (SQLException u) {
            throw new RuntimeException(u);
        }
    }

    public ArrayList listarTodos() {
        try {

            ArrayList dado = new ArrayList();

            PreparedStatement ps = connection.prepareStatement("SELECT * FROM produto");
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {

                dado.add(new Object[]{
                    rs.getInt("cod_produto"),
                    rs.getString("nome_pro"),
                    rs.getString("Marca"),
                    rs.getDouble("Preco"),
                    rs.getString("Tipo"),
                    rs.getString("Categoria"),
                    rs.getString("Quantidade"),
                });

            }
            ps.close();
            rs.close();
            connection.close();

            return dado;
        } catch (SQLException e) {
            e.getMessage();
            JOptionPane.showMessageDialog(null, "Erro preencher o ArrayList");
            return null;
        }
    }
    public static void testarConexao() throws SQLException {
        try (Connection objConnection = new ConnectionFactory().getConnection()) {
            JOptionPane.showMessageDialog(null, "Conexão realizada com sucesso! ");
        }
    }
}
